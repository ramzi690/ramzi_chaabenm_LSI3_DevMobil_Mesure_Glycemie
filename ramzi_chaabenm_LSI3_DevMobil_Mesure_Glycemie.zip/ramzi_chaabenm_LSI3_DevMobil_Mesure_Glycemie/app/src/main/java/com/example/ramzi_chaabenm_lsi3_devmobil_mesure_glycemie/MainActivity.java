    package com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

    public class MainActivity extends AppCompatActivity {
    private TextView tvage;
    private TextView tvres;
    private SeekBar sbage;
    private RadioButton rbtoui;
    private RadioButton rbtno;
    private EditText etval;
    private Button btnConsulter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        sbage.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromuser) {
                Log.i("Information","onprogresschange"+progress);
                tvage.setText("Votreâge:"+progress);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });


    }
private void init(){
        tvage=(TextView) findViewById(R.id.tvage);
        sbage=(SeekBar) findViewById(R.id.sbage);
        rbtoui=(RadioButton) findViewById(R.id.rbtoui);
        rbtno=(RadioButton) findViewById(R.id.rbtno);
        etval=(EditText) findViewById(R.id.etval);
        btnConsulter=(Button) findViewById(R.id.btnConsulter);
        tvres=(TextView) findViewById(R.id.tvres);
}
    public  void calculer(View v){
            int age;
            float valeurMesuré;
            boolean verifierAge= false;
            boolean verifierValeur=false;
            if(sbage.getProgress()!=0)
                verifierAge=true;
            else
                Toast.makeText(MainActivity.this,"veullier verifier votre age", Toast.LENGTH_SHORT);
            if(etval.getText().toString().isEmpty())
                verifierValeur=true;
            else
                Toast.makeText(MainActivity.this,"vellier verifier votre valeur",Toast.LENGTH_LONG);
            if(verifierAge && verifierValeur){
                age = sbage.getProgress();
                valeurMesuré= Float.valueOf(etval.getText().toString());
                if(rbtoui.isChecked())
                    if(age>= 13)
                        if(valeurMesuré < 5.0)
                            tvres.setText("le niveau de glycemie est bas");
                        else if (valeurMesuré>=5.0  && valeurMesuré<=7.2) {
                            tvres.setText("le niveau de glycemie est normale");
                        }
                        else
                            tvres.setText("le niveau de glycemie est elevee");
                    else if (age >=6 && age<=12)
                        if(valeurMesuré<5.0)
                            tvres.setText("niveau glycemie et bas");
                        else if (valeurMesuré >=5.0 && valeurMesuré<=10.0 )
                            tvres.setText("niveau glycemie est minimal");
                        else
                            tvres.setText("niveau eleve");
                    else
                    if(valeurMesuré<5.5)
                        tvres.setText("niveau tres bas");
                    else if(valeurMesuré>=5.5 && valeurMesuré<=10.0)
                        tvres.setText("niv est minimal");
                    else
                        tvres.setText("niveau elevé");
                else
                if (valeurMesuré<=10.5)
                    tvres.setText("niv minimal");
                else
                    tvres.setText("niveleve");

            }

        }

}